/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 5.7.26 : Database - bd_inventario2020_1
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bd_inventario2020_1` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `bd_inventario2020_1`;

/*Table structure for table `compras` */

DROP TABLE IF EXISTS `compras`;

CREATE TABLE `compras` (
  `nmcompra` int(11) NOT NULL,
  `persona_id` int(11) NOT NULL,
  `fecompra` date NOT NULL,
  PRIMARY KEY (`nmcompra`,`persona_id`),
  KEY `fk_Compras_Personas_idx` (`persona_id`),
  CONSTRAINT `fk_Compras_Personas` FOREIGN KEY (`persona_id`) REFERENCES `personas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `compras` */

/*Table structure for table `detallecompras` */

DROP TABLE IF EXISTS `detallecompras`;

CREATE TABLE `detallecompras` (
  `nmcompra` int(11) NOT NULL,
  `persona_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `nmcantidad_comprada` int(11) NOT NULL,
  `psvalor_unitario_compra` decimal(10,0) NOT NULL,
  `nmcantidad_disponible` int(11) NOT NULL,
  PRIMARY KEY (`nmcompra`,`persona_id`,`producto_id`),
  KEY `fk_detallecompras_compras1_idx` (`persona_id`,`nmcompra`),
  KEY `fk_detallecompras_productos1_idx` (`producto_id`),
  CONSTRAINT `fk_detallecompras_compras1` FOREIGN KEY (`persona_id`, `nmcompra`) REFERENCES `compras` (`persona_id`, `nmcompra`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_detallecompras_productos1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `detallecompras` */

/*Table structure for table `detalleventa` */

DROP TABLE IF EXISTS `detalleventa`;

CREATE TABLE `detalleventa` (
  `nmventa` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `nmcantidad_venta` int(11) NOT NULL,
  `psvalor_unitario_venta` decimal(10,0) NOT NULL,
  PRIMARY KEY (`nmventa`,`producto_id`),
  KEY `fk_detalleventa_productos1_idx` (`producto_id`),
  KEY `fk_detalleventa_ventas1_idx` (`nmventa`),
  CONSTRAINT `fk_detalleventa_productos1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalleventa_ventas1` FOREIGN KEY (`nmventa`) REFERENCES `ventas` (`nmventa`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `detalleventa` */

/*Table structure for table `personas` */

DROP TABLE IF EXISTS `personas`;

CREATE TABLE `personas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `telefono` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `personas` */

/*Table structure for table `productos` */

DROP TABLE IF EXISTS `productos`;

CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dsproducto` varchar(45) NOT NULL,
  `psventa` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `productos` */

/*Table structure for table `ventas` */

DROP TABLE IF EXISTS `ventas`;

CREATE TABLE `ventas` (
  `nmventa` int(11) NOT NULL,
  `persona_id` int(11) NOT NULL,
  `feventa` date NOT NULL,
  PRIMARY KEY (`nmventa`),
  KEY `fk_Ventas_Personas1_idx` (`persona_id`),
  CONSTRAINT `fk_Ventas_Personas1` FOREIGN KEY (`persona_id`) REFERENCES `personas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `ventas` */

/* Procedure structure for procedure `sp_llenar_de_datos` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_llenar_de_datos` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_llenar_de_datos`()
BEGIN
DECLARE v_CONT, v_NRO_TOTAL, v_MAX_NMCOMPRA, V_PERSONA_ID INTEGER;
DECLARE v_CONT_DETALLE, v_NRO_TOTAL_DETALLE, V_PRODUCTO_ID, V_TMP INTEGER;
DECLARE V_VAL_UNIT DECIMAL(10,0);
DECLARE v_fecha DATE;
DELETE FROM detallecompras;
DELETE FROM compras;
DELETE FROM detalleventa;
DELETE FROM ventas;
DELETE FROM personas;
DELETE FROM productos;

INSERT INTO personas(id,nombre,direccion,telefono) VALUES (1035,'juan','Calle 75 B # 46 a  12','2117576'),(1036,'felipe','Calle 75 B # 46 a  12','2117576'),(1037,'alberto','Calle 75 B # 46 a  12','2117576'),(1038,'Sebas','Calle 75 B # 46 a  12','2117576'),(1039,'Santiago','Calle 75 B # 46 a  12','2117576'),(1040,'Camilo','Calle 75 B # 46 a  12','2117576'),(1041,'Herma','Calle 75 B # 46 a  12','2117576');
INSERT INTO productos(id,dsproducto,psventa) VALUES (1101,'Golochips',4000),(1102,'Yogurt',1700),(1103,'Choclitos',1200),(1104,'DetoditoBBq',1500),(1105,'Leche entera',2900),(1106,'Arepas',1200),(1107,'Ron',27000),(1108,'Pan tajado',3200),(1109,'Papas limon',1500),(1110,'Cereal',5000),(1111,'Queso',4500),(1112,'Gaseosa',2800);


/*Generar Compras*/
SELECT FLOOR(RAND()*40)+20 INTO v_NRO_TOTAL;
SET v_CONT = 1;
SET v_fecha = DATE_SUB(CURDATE(), INTERVAL 15 DAY);
WHILE v_CONT < v_NRO_TOTAL DO
   /*Genera un ID de una persona - Persona que hace la compra*/
   SET V_PERSONA_ID = FLOOR(RAND()*(1041-1036))+1035; 
   /*Numero de factura del vendedor mas uno*/
   SELECT IFNULL( MAX( nmcompra ) ,0 ) + 1
	INTO v_MAX_NMCOMPRA
	FROM compras
	WHERE persona_id = V_PERSONA_ID;
   /*Genera Fecha, igual o mas un dia*/
   SET v_fecha = DATE_ADD(v_fecha, INTERVAL RAND() DAY);
   /*Inserta el encabezado*/
   INSERT INTO compras(nmcompra,persona_id,fecompra)
	VALUES( v_MAX_NMCOMPRA,V_PERSONA_ID, v_fecha);
   /*-- DETALLE DE LA COMPRA --*/
   SELECT FLOOR(RAND()*10)+2 INTO v_NRO_TOTAL_DETALLE;   
   SET v_CONT_DETALLE = 1;
   WHILE v_CONT_DETALLE < v_NRO_TOTAL_DETALLE DO
      SET V_PRODUCTO_ID = FLOOR(RAND()*11)+1101;
      /*vALIDAR REPETIDOS*/
      SELECT IFNULL(COUNT(*) ,0)
	INTO V_TMP 
	FROM detallecompras
	WHERE persona_id = V_PERSONA_ID AND
		nmcompra = v_MAX_NMCOMPRA AND
		producto_id = V_PRODUCTO_ID;
      /*No esta repetido*/
      IF V_TMP = 0 THEN
	/*vALOR DE VENTA*/
	SELECT IFNULL(MAX(psvalor_unitario_compra) ,100) + FLOOR(RAND()*10) - 5
		INTO V_VAL_UNIT 
		FROM detallecompras
		WHERE producto_id = V_PRODUCTO_ID;
	
	SET V_TMP = FLOOR(RAND()*20) +1;
	INSERT INTO detallecompras(persona_id,nmcompra,producto_id,nmcantidad_comprada,psvalor_unitario_compra, nmcantidad_disponible)
		VALUES( V_PERSONA_ID, v_MAX_NMCOMPRA, V_PRODUCTO_ID, V_TMP, V_VAL_UNIT, V_TMP);
      END IF;
      SET v_CONT_DETALLE = v_CONT_DETALLE + 1;
   END WHILE;
   
   
   SET v_CONT = v_CONT + 1;
END WHILE;

END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
