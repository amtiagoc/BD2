/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 5.7.26 : Database - metro
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`metro` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `metro`;

/*Table structure for table `estaciones` */

DROP TABLE IF EXISTS `estaciones`;

CREATE TABLE `estaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `estaciones` */

/*Table structure for table `registros` */

DROP TABLE IF EXISTS `registros`;

CREATE TABLE `registros` (
  `fecha_hora` timestamp NOT NULL,
  `serial` int(11) NOT NULL,
  PRIMARY KEY (`fecha_hora`,`serial`),
  KEY `fk_registros_torniquetes1_idx` (`serial`),
  CONSTRAINT `fk_registros_torniquetes1` FOREIGN KEY (`serial`) REFERENCES `torniquetes` (`serial`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `registros` */

/*Table structure for table `torniquetes` */

DROP TABLE IF EXISTS `torniquetes`;

CREATE TABLE `torniquetes` (
  `serial` int(11) NOT NULL AUTO_INCREMENT,
  `entrada_o_salida` char(1) NOT NULL DEFAULT 'E',
  `estacion_id` int(11) NOT NULL,
  PRIMARY KEY (`serial`),
  KEY `fk_Torniquetes_Estaciones_idx` (`estacion_id`),
  CONSTRAINT `fk_Torniquetes_Estaciones` FOREIGN KEY (`estacion_id`) REFERENCES `estaciones` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3005 DEFAULT CHARSET=utf8;

/*Data for the table `torniquetes` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
